rj = __import__('topsis')
rj.topsis()